<!-- on reprend l'entête de l'Ex, on change les href pour ne plus mettre le nom des pages, mais seulement ce que l'on veut dans l'url -->

<ul class="flexible space-evenly">
    <!-- grand écran -->
    <li class="menu"><a href="/">Home</a></li>  <!-- index.php devient / -->
    <li  class="menu"><a href="inscription">Inscription</a></li>
    <li  class="menu"><a href="connexion">Connexion</a></li>    <!-- par la suite, on fera en sorte que l'on voie déconnexion ou connexion 
                                                                    selon la situtation -->
    <!-- petit écran -->
    <li class="imageMenu"><a href="/"><ion-icon size="large" name="home-outline"></ion-icon></a></li>
    <li class="imageMenu"><a href="inscription"><ion-icon size="large" name="person-outline"></ion-icon></a></li>
    <li class="imageMenu"> <a href="connexion"><ion-icon size="large" name="enter-outline"></ion-icon></a></li>
</ul>